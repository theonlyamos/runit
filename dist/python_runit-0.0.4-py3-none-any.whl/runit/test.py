def multiply(*numbers):
    '''
    Multiply numbers

    @param numbers
    @return None
    '''
    print(numbers)

def add(*numbers):
    '''
    Add numbers

    @param numbers
    @return None
    '''
    print(numbers)

def minus(num1: int, num2: int):
    '''
    Substract num2 from num1

    @param num1
    @param num1
    @return None
    '''
    print(num1 - num2)
